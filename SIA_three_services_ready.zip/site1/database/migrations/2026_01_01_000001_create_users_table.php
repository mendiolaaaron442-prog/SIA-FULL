<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username', 20)->unique();
            $table->string('password');
            $table->enum('gender', ['Male', 'Female']);
            $table->unsignedInteger('jobid');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
