<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('userjob', function (Blueprint $table) {
            $table->unsignedInteger('jobid')->primary();
            $table->string('jobname', 50);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('userjob');
    }
};
