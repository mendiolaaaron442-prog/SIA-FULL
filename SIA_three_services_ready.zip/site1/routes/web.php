<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('/test', function () {
    return 'OK';
});

$router->get('/test-db', function () {
    try {
        DB::connection()->getPdo();
        return "Connected successfully to database: " . DB::connection()->getDatabaseName();
    } catch (\Exception $e) {
        return "Could not connect to the database. Error: " . $e->getMessage();
    }
});

$router->group(['middleware' => 'auth.access'], function () use ($router) {

    // Users CRUD
    $router->get('/users', 'UserController@index');
    $router->post('/users', 'UserController@add');
    $router->get('/users/{id}', 'UserController@show');
    $router->put('/users/{id}', 'UserController@update');
    $router->patch('/users/{id}', 'UserController@update');
    $router->delete('/users/{id}', 'UserController@delete');

    // UserJob lookup (used by Gateway to validate jobids)
    $router->get('/userjob', 'UserJobController@index');
    $router->get('/userjob/{id}', 'UserJobController@show');
});
