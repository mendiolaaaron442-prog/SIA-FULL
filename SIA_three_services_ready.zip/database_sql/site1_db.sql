CREATE DATABASE IF NOT EXISTS site1_db;
USE site1_db;

CREATE TABLE IF NOT EXISTS userjob (
    jobid INT PRIMARY KEY,
    jobname VARCHAR(50) NOT NULL
);

INSERT INTO userjob (jobid, jobname) VALUES
(1, 'Manager'),
(2, 'Supervisor'),
(3, 'Cashier'),
(4, 'Clerk'),
(5, 'Encoder')
ON DUPLICATE KEY UPDATE jobname = VALUES(jobname);

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    jobid INT NOT NULL
);
