CREATE DATABASE IF NOT EXISTS site2_db;
USE site2_db;

CREATE TABLE IF NOT EXISTS jobroles (
    jobid INT PRIMARY KEY,
    jobname VARCHAR(50) NOT NULL
);

INSERT INTO jobroles (jobid, jobname) VALUES
(6, 'Accountant'),
(7, 'Analyst'),
(8, 'Developer'),
(9, 'HR'),
(10, 'Support')
ON DUPLICATE KEY UPDATE jobname = VALUES(jobname);

CREATE TABLE IF NOT EXISTS employees (
    empID INT AUTO_INCREMENT PRIMARY KEY,
    empName VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    jobid INT NOT NULL
);
