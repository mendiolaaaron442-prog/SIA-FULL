<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->increments('empID');
            $table->string('empName', 20);
            $table->string('password');
            $table->enum('gender', ['Male', 'Female']);
            $table->unsignedInteger('jobid');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('employees');
    }
};
