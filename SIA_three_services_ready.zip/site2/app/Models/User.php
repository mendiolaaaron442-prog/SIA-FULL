<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = 'employees';
// column sa table
    protected $fillable = 
        ['empName', 'password', 'gender', 'jobid'];

    protected $hidden =
        ['password',];
    
    public $timestamps = false;
    protected $primaryKey = 'empID';
}
