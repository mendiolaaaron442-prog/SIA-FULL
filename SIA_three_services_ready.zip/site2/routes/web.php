<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

//Test your remote service
$router->get('/test', function () {
    return 'OK';
});

$router->get('/test-db', function () {
    try {
        DB::connection()->getPdo();
        return "Connected successfully to database: " . DB::connection()->getDatabaseName();
    } catch (\Exception $e) {
        return "Could not connect to the database. Error: " . $e->getMessage();
    }
});

/*
// unsecure routes 
$router->group(['prefix' => 'api'], function () use ($router) {
    $router->get('/users2',['uses' => 'UserController@getUsers']);
});
*/

$router->group(['middleware' => 'auth.access'], function () use ($router) {
    // more simple routes 
    $router->get('/employees', 'UserController@index');   // Get all users
    $router->post('/employees', 'UserController@add');  // create new user 
    $router->get('/employees/{empID}', 'UserController@show'); // get user by id
    $router->put('/employees/{empID}', 'UserController@update'); // update user 
    $router->patch('/employees/{empID}', 'UserController@update'); // update user 
    $router->delete('/employees/{empID}', 'UserController@delete'); // delete 

    //for userjob
    $router->get('/jobroles', 'UserJobController@index'); 
    $router->get('/jobroles/{empID}', 'UserJobController@show'); // get user by id
});