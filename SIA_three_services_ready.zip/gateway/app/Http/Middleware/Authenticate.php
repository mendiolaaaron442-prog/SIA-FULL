<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;

class Authenticate
{
    public function handle($request, Closure $next)
    {
        $header = $request->header('Authorization');

        if (!$header || !preg_match('/Bearer\s+(.*)$/i', $header, $matches)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $hashedToken = hash('sha256', trim($matches[1]));
        $user = User::where('api_token', $hashedToken)->first();

        if (!$user) {
            return response()->json(['message' => 'Invalid token'], 401);
        }

        $request->attributes->set('auth_user', $user);

        return $next($request);
    }
}
