<?php

namespace App\Http\Controllers;

use App\Services\User2Service;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class User2Controller extends Controller
{
    use ApiResponser;

    public $user2Service;

    public function __construct(User2Service $user2Service)
    {
        $this->user2Service = $user2Service;
    }

    public function index()
    {
        return $this->successResponse($this->user2Service->obtainUsers2());
    }

    public function add(Request $request)
    {
        $this->validate($request, [
            'empName' => 'required|max:20',
            'password' => 'required|max:20',
            'gender' => 'required|in:Male,Female',
            'jobid' => 'required|integer|min:1',
        ]);

        $job = $this->user2Service->obtainUserJob($request->jobid);

        if (isset($job['message']) || isset($job['error'])) {
            return $this->errorResponse('Job not found in Site 2', 404);
        }

        return $this->successResponse(
            $this->user2Service->createUser2($request->all()),
            Response::HTTP_CREATED
        );
    }

    public function show($empID)
    {
        return $this->successResponse($this->user2Service->obtainUser2($empID));
    }

    public function update(Request $request, $empID)
    {
        $this->validate($request, [
            'empName' => 'required|max:20',
            'password' => 'required|max:20',
            'gender' => 'required|in:Male,Female',
            'jobid' => 'required|integer|min:1',
        ]);

        $job = $this->user2Service->obtainUserJob($request->jobid);

        if (isset($job['message']) || isset($job['error'])) {
            return $this->errorResponse('Job not found in Site 2', 404);
        }

        return $this->successResponse($this->user2Service->editUser2($request->all(), $empID));
    }

    public function delete($empID)
    {
        return $this->successResponse($this->user2Service->deleteUser2($empID));
    }
}
