<?php

namespace App\Http\Controllers;

use App\Services\User1Service;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class User1Controller extends Controller
{
    use ApiResponser;

    public $user1Service;

    public function __construct(User1Service $user1Service)
    {
        $this->user1Service = $user1Service;
    }

    public function index()
    {
        return $this->successResponse($this->user1Service->obtainUsers1());
    }

    public function add(Request $request)
    {
        $this->validate($request, [
            'username' => 'required|max:20',
            'password' => 'required|max:20',
            'gender' => 'required|in:Male,Female',
            'jobid' => 'required|integer|min:1',
        ]);

        $job = $this->user1Service->obtainUserJob($request->jobid);

        if (isset($job['message']) || isset($job['error'])) {
            return $this->errorResponse('Job not found in Site 1', 404);
        }

        return $this->successResponse(
            $this->user1Service->createUser1($request->all()),
            Response::HTTP_CREATED
        );
    }

    public function show($id)
    {
        return $this->successResponse($this->user1Service->obtainUser1($id));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'username' => 'required|max:20',
            'password' => 'required|max:20',
            'gender' => 'required|in:Male,Female',
            'jobid' => 'required|integer|min:1',
        ]);

        $job = $this->user1Service->obtainUserJob($request->jobid);

        if (isset($job['message']) || isset($job['error'])) {
            return $this->errorResponse('Job not found in Site 1', 404);
        }

        return $this->successResponse($this->user1Service->editUser1($request->all(), $id));
    }

    public function delete($id)
    {
        return $this->successResponse($this->user1Service->deleteUser1($id));
    }
}
