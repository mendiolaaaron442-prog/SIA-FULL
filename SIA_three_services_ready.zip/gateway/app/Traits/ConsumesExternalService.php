<?php

namespace App\Traits;

trait ConsumesExternalService
{
    public function performRequest($method, $requestUrl, $formParams = [], $headers = [])
    {
        $url = rtrim($this->baseUri, '/') . '/' . ltrim($requestUrl, '/');

        $ch = curl_init();

        if (isset($this->secret) && $this->secret !== '') {
            $headers['Authorization'] = $this->secret;
        }

        $finalHeaders = ['Accept: application/json'];

        foreach ($headers as $key => $value) {
            $finalHeaders[] = $key . ': ' . $value;
        }

        $method = strtoupper($method);

        if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE']) && !empty($formParams)) {
            $finalHeaders[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($formParams));
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $finalHeaders,
        ]);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);

            return [
                'message' => 'Service request failed',
                'error' => $error,
            ];
        }

        curl_close($ch);

        $decoded = json_decode($response, true);

        return $decoded ?? [
            'message' => 'Invalid response from service',
            'raw' => $response,
        ];
    }
}
