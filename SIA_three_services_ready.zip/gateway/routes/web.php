<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('/test', function () {
    return 'OK';
});

$router->get('/test-db', function () {
    try {
        DB::connection()->getPdo();
        return 'Connected successfully to database: ' . DB::connection()->getDatabaseName();
    } catch (\Exception $e) {
        return 'Could not connect to the database. Error: ' . $e->getMessage();
    }
});

$router->post('/register', 'AuthController@register');
$router->post('/login', 'AuthController@login');

$router->group(['middleware' => 'auth'], function () use ($router) {
    $router->get('/me', 'AuthController@me');

    $router->get('/users', 'User1Controller@index');
    $router->post('/users', 'User1Controller@add');
    $router->get('/users/{id}', 'User1Controller@show');
    $router->put('/users/{id}', 'User1Controller@update');
    $router->patch('/users/{id}', 'User1Controller@update');
    $router->delete('/users/{id}', 'User1Controller@delete');

    $router->get('/employees', 'User2Controller@index');
    $router->post('/employees', 'User2Controller@add');
    $router->get('/employees/{empID}', 'User2Controller@show');
    $router->put('/employees/{empID}', 'User2Controller@update');
    $router->patch('/employees/{empID}', 'User2Controller@update');
    $router->delete('/employees/{empID}', 'User2Controller@delete');
});
