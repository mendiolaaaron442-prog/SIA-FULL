MICROSERVICES SETUP GUIDE

Folders:
- gateway
- site1
- site2

1) Create the databases
Import these files in MySQL:
- database_sql/gateway_db.sql
- database_sql/site1_db.sql
- database_sql/site2_db.sql

2) Install packages in each folder
Open three terminals and run:
- cd gateway && composer install
- cd site1 && composer install
- cd site2 && composer install

3) Create .env in each folder
Copy .env.example to .env for gateway, site1, and site2.
If your MySQL password is not blank, update DB_PASSWORD in all three.

4) Start the services

Gateway
php -S 127.0.0.1:8000 -t public

Site 1
php -S 127.0.0.1:8001 -t public

Site 2
php -S 127.0.0.1:8002 -t public

5) Quick checks
- http://127.0.0.1:8000/test
- http://127.0.0.1:8001/test
- http://127.0.0.1:8002/test

6) Postman flow

Register in Gateway
POST http://127.0.0.1:8000/register
{
  "username": "admin",
  "password": "12345"
}

Login in Gateway
POST http://127.0.0.1:8000/login
{
  "username": "admin",
  "password": "12345"
}

Copy the token and use:
Authorization: Bearer YOUR_TOKEN_HERE

Sample Site 1 request through Gateway
POST http://127.0.0.1:8000/users
{
  "username": "mark",
  "password": "12345",
  "gender": "Male",
  "jobid": 1
}

Sample Site 2 request through Gateway
POST http://127.0.0.1:8000/employees
{
  "empName": "anna",
  "password": "12345",
  "gender": "Female",
  "jobid": 6
}

7) GitHub upload
Upload gateway, site1, and site2 as separate repositories if needed.
The .gitignore files are ready, so vendor and .env will not be pushed.
